// Val Town HTTP val: "ocr-proxy"  (v3: smooth rotation over any number of keys)
// Frontend: https://examyatra.github.io/QuizGPT/  ->  POST { image: "data:image/jpeg;base64,...", lang: "eng" | "hin" | "eng+hin" }
// Success : 200 { ok:true, text, provider, engine }
// Image   : 422 { ok:false, kind:"image", error, details }   (bad / too big / unreadable image: other keys are NOT burned)
// Keys    : 502 { ok:false, kind:"keys",  error, details }   (every key failed: rate limit, quota, invalid key, timeout...)
// Other   : 400 bad request, 403 Forbidden (wrong origin), 405 wrong method
//
// ENV (any of these, mixed is fine):
//   OCR_KEYS   = ocrspace:KEY1,ocrspace:KEY2,googlevision:KEY3     (spaces around ':' and ',' are ignored)
//   OCRSPACE_1 = KEY1, OCRSPACE_2 = KEY2 ...                        (one variable per key)
//   GOOGLEVISION_1 = KEY ...                                        (optional)
// Add or remove a key in the Environment variables -> it is picked up on the very next request. No code change.
// v3: least-recently-used rotation, one request per key at a time + small gap, growing rest time for limited keys,
//     invalid keys rest 24h, identical images cached, per-IP safety limit, GET = key counts (no key values).

const ALLOWED = ["https://examyatra.github.io"]; // origin only, no path
const MAX_TRIES = 8;                    // max key attempts per request
const FETCH_TIMEOUT_MS = 25_000;
const TOTAL_DEADLINE_MS = 36_000;       // website waits max 40 s
const KEY_GAP_MS = 800;                 // min gap between two requests on the same key
const IP_LIMIT = 150, IP_WINDOW_MS = 10 * 60_000;   // per visitor IP: max requests per 10 min (stops outsiders burning your keys)
const CACHE_MAX = 300, CACHE_TTL_MS = 30 * 60_000;
const MAX_IMAGE_CHARS = 1_400_000;      // dataURL length cap (~1 MB binary)

type Key = { provider: "ocrspace" | "googlevision"; key: string };
type Kind = "image" | "key" | "dead" | "transient";
class OcrErr extends Error {
  kind: Kind;
  constructor(kind: Kind, msg: string) { super(msg); this.kind = kind; }
}

// ---------- keys ----------
function normProvider(p: string): Key["provider"] | null {
  p = p.trim().toLowerCase().replace(/[^a-z]/g, "");
  if (p === "ocrspace" || p === "ocr") return "ocrspace";
  if (p === "googlevision" || p === "google" || p === "gvision" || p === "vision") return "googlevision";
  return null;
}
function loadKeys(): Key[] {
  const out: Key[] = [];
  const seen = new Set<string>();
  const add = (provider: Key["provider"] | null, key: string) => {
    key = (key || "").trim();
    if (!provider || !key) return;
    const id = provider + ":" + key;
    if (seen.has(id)) return;
    seen.add(id); out.push({ provider, key });
  };
  const raw = Deno.env.get("OCR_KEYS") || "";
  for (const part of raw.split(",")) {
    const p = part.trim();
    if (!p) continue;
    const i = p.indexOf(":");
    if (i < 0) add("ocrspace", p);                       // bare key = OCR.space
    else add(normProvider(p.slice(0, i)), p.slice(i + 1));
  }
  for (const k of (Deno.env.get("OCR_SPACE_KEYS") || "").split(",")) add("ocrspace", k); // old format still works
  const env = Deno.env.toObject();
  for (const [name, val] of Object.entries(env)) {
    const m = name.match(/^(OCRSPACE|GOOGLEVISION|GOOGLE_VISION)_?\d*$/i);
    if (m) add(normProvider(m[1]), val);
  }
  return out;
}

// ---------- key health (in memory, resets when the val restarts) ----------
// Rest time grows with repeated limit errors: 10m, 30m, 1h, 3h, 6h. Success resets it. Invalid key: 24h.
// Per engine: OCR.space Engine 3 (Hindi) has its own quota; Google Vision is tracked as "gv".
const cooldown = new Map<string, number>();
const strikes = new Map<string, number>();
const dead = new Map<string, number>();
const busy = new Map<string, { inflight: number; nextAt: number; lastUsed: number }>();
const eng = (k: Key, engine: string) => (k.provider === "googlevision" ? "gv" : engine);
const kid = (k: Key) => `${k.provider}:${k.key}`;
const cdId = (k: Key, engine: string) => `${kid(k)}:${eng(k, engine)}`;
const isCooling = (k: Key, engine: string) => (cooldown.get(cdId(k, engine)) || 0) > Date.now() || (dead.get(kid(k)) || 0) > Date.now();
const STEPS = [10, 30, 60, 180, 360];   // minutes
function coolDown(k: Key, engine: string, fast = false) {
  const id = cdId(k, engine), n = (strikes.get(id) || 0) + 1;
  strikes.set(id, n);
  cooldown.set(id, Date.now() + (fast ? 20_000 : STEPS[Math.min(n, STEPS.length) - 1] * 60_000));
}
const markGood = (k: Key, engine: string) => strikes.delete(cdId(k, engine));
const st = (k: Key) => { let s = busy.get(kid(k)); if (!s) { s = { inflight: 0, nextAt: 0, lastUsed: 0 }; busy.set(kid(k), s); } return s; };

// least recently used, free key first (random tie-break); keys still busy / in their gap are skipped
function pickKey(all: Key[], engine: string, tried: Set<string>): { k: Key | null; alive: boolean } {
  const now = Date.now();
  let best: Key | null = null, bestScore = Infinity, alive = false;
  for (const k of all) {
    if (tried.has(kid(k)) || isCooling(k, engine)) continue;
    alive = true;
    const s = st(k);
    if (s.inflight > 0 || s.nextAt > now) continue;
    const score = s.lastUsed + Math.random() * 50;
    if (score < bestScore) { best = k; bestScore = score; }
  }
  return { k: best, alive };
}
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

// ---------- cache + per-IP limit ----------
const cache = new Map<string, { text: string; t: number }>();
async function sha(t: string): Promise<string> {
  const b = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(t));
  return [...new Uint8Array(b)].map((x) => x.toString(16).padStart(2, "0")).join("");
}
function cacheGet(k: string): string | null {
  const e = cache.get(k);
  if (!e) return null;
  if (Date.now() - e.t > CACHE_TTL_MS) { cache.delete(k); return null; }
  return e.text;
}
function cacheSet(k: string, text: string) {
  if (cache.size >= CACHE_MAX) cache.delete(cache.keys().next().value as string);
  cache.set(k, { text, t: Date.now() });
}
const ipHits = new Map<string, { n: number; t: number }>();
function ipLimited(ip: string): boolean {
  const now = Date.now();
  if (ipHits.size > 2000) for (const [k, v] of ipHits) if (now - v.t > IP_WINDOW_MS) ipHits.delete(k);
  const h = ipHits.get(ip);
  if (!h || now - h.t > IP_WINDOW_MS) { ipHits.set(ip, { n: 1, t: now }); return false; }
  return ++h.n > IP_LIMIT;
}

// ---------- error classification ----------
// Key-level problems are checked first ("limit exceeded" must not be mistaken for "file size exceeds").
const KEY_RE = /exceed(ed|s)?.{0,50}(requests?|quota|usage)|maximum number of requests|requests?.{0,20}(per|a) (day|month|hour|minute)|(request|quota|rate|usage|daily|monthly).{0,40}(limit|exceed|reach)|(limit|quota).{0,30}(reached|exceeded)|too many requests|api ?key|apikey|unauthori[sz]ed|not authori[sz]ed|forbidden|billing|permission|suspend|disabled/i;
const IMAGE_RE = /file ?size|too (large|big)|size|dimension|pixel|resolution|width|height|unable to|cannot (read|recogni)|could not (read|recogni)|not (a )?valid (image|file)|file ?type|file ?format|unsupported|corrupt|invalid (image|file|base64)|bad image|empty|no (text|image)/i;

const DEAD_RE = /(invalid|not valid|unknown|revoked|deleted|disabled|blocked|suspend).{0,30}(api ?key|apikey|key)|(api ?key|apikey).{0,30}(invalid|not valid|unknown|revoked|deleted|disabled|blocked)/i;
function classify(status: number, msg: string): Kind {
  if (DEAD_RE.test(msg) && !/limit|quota|exceed/i.test(msg)) return "dead";
  if (status === 401 || status === 403 || status === 429) return "key";
  if (KEY_RE.test(msg)) return "key";
  if (IMAGE_RE.test(msg)) return "image";
  return "transient"; // timeouts, 5xx, unknown: try the next key, but don't punish this one
}

// ---------- adapters ----------
async function timedFetch(url: string, init: RequestInit): Promise<Response> {
  try {
    return await fetch(url, { ...init, signal: AbortSignal.timeout(FETCH_TIMEOUT_MS) });
  } catch (e) {
    throw new OcrErr("transient", "network/timeout: " + (e instanceof Error ? e.message : String(e)));
  }
}

async function ocrSpace(k: Key, image: string, lang: string, engine: string): Promise<string> {
  const hin = engine === "3";
  const fd = new FormData();
  fd.append("apikey", k.key);
  fd.append("base64Image", image);                 // full data URL is accepted
  fd.append("language", hin ? "hin" : "eng");
  fd.append("OCREngine", engine);
  fd.append("isOverlayRequired", "false");
  fd.append("detectOrientation", "true");
  fd.append("scale", "true");
  const r = await timedFetch("https://api.ocr.space/parse/image", { method: "POST", body: fd });
  const bodyText = await r.text();
  let j: any = null;
  try { j = JSON.parse(bodyText); } catch { /* not JSON */ }
  if (!j) throw new OcrErr(classify(r.status, bodyText), `HTTP ${r.status}: ${bodyText.slice(0, 200)}`);

  // OCR.space often reports errors in the body with HTTP 200
  const errs: string[] = [];
  const em = j.ErrorMessage;
  if (Array.isArray(em)) errs.push(...em.map(String)); else if (em) errs.push(String(em));
  if (j.ErrorDetails) errs.push(String(j.ErrorDetails));
  for (const pr of j.ParsedResults || []) if (pr && pr.ErrorMessage) errs.push(String(pr.ErrorMessage));
  const msg = errs.join(" | ");
  if (j.IsErroredOnProcessing || r.status >= 400 || j.OCRExitCode >= 3) {
    throw new OcrErr(classify(r.status, msg), msg || `HTTP ${r.status}`);
  }
  return (j.ParsedResults || []).map((p: any) => p.ParsedText || "").join("\n").trim();
}

async function googleVision(k: Key, image: string, lang: string): Promise<string> {
  const b64 = image.replace(/^data:[^,]+,/, "");
  const hints = lang.includes("hin") ? ["hi", "en"] : ["en"];
  const r = await timedFetch(`https://vision.googleapis.com/v1/images:annotate?key=${encodeURIComponent(k.key)}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ requests: [{ image: { content: b64 }, features: [{ type: "DOCUMENT_TEXT_DETECTION" }], imageContext: { languageHints: hints } }] }),
  });
  const j: any = await r.json().catch(() => null);
  const msg = j?.error?.message || j?.responses?.[0]?.error?.message || "";
  if (!r.ok || j?.error) throw new OcrErr(classify(r.status, msg), msg || `HTTP ${r.status}`);
  return (j?.responses?.[0]?.fullTextAnnotation?.text || "").trim();
}

// ---------- http helpers ----------
function cors(origin: string): Record<string, string> {
  return {
    "Access-Control-Allow-Origin": origin,
    "Access-Control-Allow-Methods": "POST, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Max-Age": "86400",
    "Vary": "Origin",
  };
}
function json(obj: unknown, status: number, origin: string): Response {
  return new Response(JSON.stringify(obj), { status, headers: { "Content-Type": "application/json", ...cors(origin) } });
}

// ---------- main ----------
export default async function (req: Request): Promise<Response> {
  const origin = req.headers.get("origin") || "";

  // plain GET (browser address bar): only counts, never key values
  if (req.method === "GET") {
    const all = loadKeys(), now = Date.now();
    return new Response(JSON.stringify({
      ok: true, keys: all.length,
      readyEnglish: all.filter((k) => !isCooling(k, "2")).length,
      readyHindi: all.filter((k) => !isCooling(k, "3")).length,
      invalid: all.filter((k) => (dead.get(kid(k)) || 0) > now).length,
      cached: cache.size,
    }), { headers: { "Content-Type": "application/json" } });
  }

  if (!ALLOWED.includes(origin)) return new Response("Forbidden", { status: 403 });

  if (req.method === "OPTIONS") return new Response(null, { status: 204, headers: cors(origin) });
  if (req.method !== "POST") return json({ ok: false, error: "POST only" }, 405, origin);

  const ip = (req.headers.get("x-forwarded-for") || "").split(",")[0].trim() || "unknown";
  if (ipLimited(ip)) return json({ ok: false, kind: "transient", error: "too many requests, slow down" }, 429, origin);

  let body: any;
  try { body = await req.json(); } catch { return json({ ok: false, kind: "image", error: "bad JSON" }, 400, origin); }
  const image = typeof body?.image === "string" ? body.image : "";
  const lang = typeof body?.lang === "string" ? body.lang.toLowerCase() : "eng";

  if (!/^data:image\/(jpeg|jpg|png|webp|gif|bmp);base64,/i.test(image)) {
    return json({ ok: false, kind: "image", error: "image must be a base64 data URL" }, 422, origin);
  }
  if (image.length > MAX_IMAGE_CHARS) {
    return json({ ok: false, kind: "image", error: "image too large", details: `${image.length} chars > ${MAX_IMAGE_CHARS}` }, 422, origin);
  }
  // Sanskrit is never sent to the cloud (defence in depth; the frontend blocks it too)
  if (lang.includes("san")) return json({ ok: false, kind: "image", error: "Sanskrit is offline-only" }, 422, origin);

  // Hindi -> Engine 3 (language hin). Everything else -> Engine 2 (eng).
  const engine = lang.includes("hin") ? "3" : "2";

  const all = loadKeys();
  if (!all.length) return json({ ok: false, kind: "keys", error: "no API keys configured" }, 502, origin);

  const ck = (await sha(image)) + "|" + engine;
  const hit = cacheGet(ck);
  if (hit !== null) return json({ ok: true, text: hit, cached: true }, 200, origin);

  const details: string[] = [];
  const tried = new Set<string>();
  const started = Date.now();
  let tries = 0;
  while (tries < MAX_TRIES && Date.now() - started < TOTAL_DEADLINE_MS) {
    const { k, alive } = pickKey(all, engine, tried);
    if (!k) {
      if (!alive) break;            // every remaining key is resting or already tried
      await sleep(120);             // keys exist but are busy / in their gap: wait a moment
      continue;
    }
    tries++; tried.add(kid(k));
    const s = st(k);
    s.inflight++; s.lastUsed = Date.now();
    try {
      const text = k.provider === "ocrspace" ? await ocrSpace(k, image, lang, engine) : await googleVision(k, image, lang);
      markGood(k, engine);
      if (text) cacheSet(ck, text);
      return json({ ok: true, text, provider: k.provider, engine }, 200, origin);
    } catch (e) {
      const err = e instanceof OcrErr ? e : new OcrErr("transient", String(e));
      console.log(`[ocr] ${k.provider} key ...${k.key.slice(-4)} engine ${engine} -> ${err.kind}: ${err.message}`);
      if (err.kind === "image") {
        // the image itself is the problem: stop now, do not burn the remaining keys
        return json({ ok: false, kind: "image", error: err.message, details: err.message }, 422, origin);
      }
      if (err.kind === "dead") { dead.set(kid(k), Date.now() + 24 * 3600_000); }
      else if (err.kind === "key") { coolDown(k, engine, /per (second|minute)|too many requests/i.test(err.message) && !/day|month/i.test(err.message)); }
      details.push(`${k.provider}...${k.key.slice(-4)}: ${err.message}`.slice(0, 160));
    } finally {
      s.inflight--; s.nextAt = Date.now() + KEY_GAP_MS;
    }
  }
  // every key is resting / limited -> "keys" (website goes offline for a while); only temporary trouble -> "transient" (only this page goes offline)
  const anyUsable = all.some((k) => !isCooling(k, engine));
  if (!anyUsable) {
    return json({ ok: false, kind: "keys", error: "all OCR keys failed", details: details.join(" || ") }, 502, origin);
  }
  return json({ ok: false, kind: "transient", error: "OCR busy, try again", details: details.join(" || ") }, 503, origin);
}
